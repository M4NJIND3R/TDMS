﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace TDMS
{
    public partial class DatabaseForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\chait\\OneDrive\\Desktop\\Neh\\TDMS-main\\TDMS-main\\Database1.mdf;");

        public DatabaseForm()
        {
            InitializeComponent();
        }
        private void DatabaseForm_Load(object sender, EventArgs e)
        {
            try {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Customer", con);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                
                DataTable dt = new DataTable();

                dataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;
                con.Close();

            }
            catch(Exception ex)
            {
                MessageBox.Show("error: " + ex.Message);
            }

            
        }
       

        public void Home_click(Object sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
