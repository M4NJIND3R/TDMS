﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TDMS
{
    public partial class PlanForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\chait\\OneDrive\\Desktop\\Neh\\TDMS-main\\TDMS-main\\Database1.mdf;");

        public PlanForm()
        {
            InitializeComponent();
        }

        public void back_click(Object Sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Close();
        }

        public void submit_click(object sender, EventArgs e)
        {
            try {
                string radioButtons = "";


                con.Open();
                if (radioButton1.Checked)
                {

                    radioButtons = "Update Customer set plan = 'basic' where id = ('select max(id) from Customer;')";

                }
                else if (radioButton2.Checked)
                {

                    radioButtons = "Update Customer set plan = 'standard' where id = (SELECT id FROM Customer order by id desc limit 1;)";

                }
                else if (radioButton3.Checked)
                {
                    radioButtons = "Update Customer set plan = 'premium' where id = (SELECT id FROM Customer order by id desc limit 1;)";
                }
                SqlCommand cmd = new SqlCommand(radioButtons, con);


                cmd.ExecuteNonQuery();
                con.Close();



                var answer = MessageBox.Show("Are you sure the filled in Information is Accurate and you have selected desired plan ?", "", MessageBoxButtons.YesNo);
                if (answer.ToString().ToLower().Equals("yes"))
                {
                    MessageBox.Show("Customer Added Successfully");
                    HomeForm homeForm = new HomeForm();
                    homeForm.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please reselect");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("error");
            }

        }

        private void PlanForm_Load(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
