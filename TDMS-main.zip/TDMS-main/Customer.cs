﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TDMS
{
    public class Customer1
    {
        private string firstName, lastName, email, streetAdd1, streetAdd2, City, Province;
        private int countryCode;
        private long phoneNum;
        private string Plan;


        public Customer1(string fName, string lName, string email, string strAdd1,
            string strAdd2, string city, string province, int ctrCode, long phNum)
        {
            this.firstName=fName;
            this.lastName = lName;
            this.email = email;
            this.streetAdd1 = strAdd1;
            this.streetAdd2 = strAdd2;
            this.City = city;
            this.Province = province;
            this.countryCode = ctrCode;
            this.phoneNum = phNum;
            
           
        }

        
    }
}

