﻿using System.Data.Linq.Mapping;

namespace TDMS
{
    [Table(Name = "dbo.Customer")]
    public class CustomerBase
    {
    }
}