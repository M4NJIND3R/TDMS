﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TDMS
{
    public partial class NewCustForm : Form
    {

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\chait\\OneDrive\\Desktop\\Neh\\TDMS-main\\TDMS-main\\Database1.mdf;");

        public NewCustForm()
        {
            InitializeComponent();
        }

        public void cancel_click(Object sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Close();
        }

        public void next_click(Object sender, EventArgs e)
        {
            try
            {

                //collecting data entered from user and entering it into database
                //Customer newCust = new Customer(firstNameTextBox.Text, lastNameTextBox.Text, emailTextBox.Text,
                  //                                 strAdd1TextBox.Text, strAdd2TextBox.Text, cityTextBox.Text,
                    //                               provinceTextBox.Text,Convert.ToInt32(countryCodeTextBox.Text),
                      //                             Convert.ToInt32(phoneTextBox.Text));
                
                string insertQuery = "INSERT INTO Customer(" +
                                        "FirstName,LastName," +
                                        "Email,PhoneNumber," +
                                        "streetAdd1," +
                                        "countrycode,City," +
                                        "Province,streetAdd2" +
                                        ")VALUES('" +
                                        firstNameTextBox.Text + "','" + lastNameTextBox.Text + 
                                        "','" + emailTextBox.Text + "','" + Convert.ToInt32(phoneTextBox.Text)
                                        + "','" + strAdd1TextBox.Text + "','" + Convert.ToInt32(countryCodeTextBox.Text) +
                                        "','" + cityTextBox.Text + "','" + provinceTextBox.Text
                                        + "','" + strAdd2TextBox.Text + "')";
                con.Open();

                SqlCommand cmd = new SqlCommand(insertQuery, con);
                SqlDataReader readData;
                readData = cmd.ExecuteReader();


                PlanForm planForm = new PlanForm();
                planForm.Show();
                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("error: " + ex.Message);
            }
        }

        private void NewCustForm_Load(object sender, EventArgs e)
        {

        }
    }
}
