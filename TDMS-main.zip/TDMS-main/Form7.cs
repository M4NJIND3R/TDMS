﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TDMS
{
    public partial class DeleteForm : Form
    {


        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\chait\\OneDrive\\Desktop\\Neh\\TDMS-main\\TDMS-main\\Database1.mdf;");


        public DeleteForm()
        {
            InitializeComponent();
        }

        //removing the selected user from the database, using their email
        public void unsbscribe_Click(object sender, EventArgs e)
        {
            try
            {
                if(emailBox.Text.Length>0 && phNumTextBox.Text.Length > 0)
                {
                    MessageBox.Show("please try in only one!");
                }
                else if(emailBox.Text.Length > 0)
                {
                    //removing selected user from the database
                    con.Open();
                    string deleteQuery = "DELETE FROM Customer WHERE Email = '" + emailBox.Text+"'";

                    con.Open();

                    SqlCommand cmd = new SqlCommand(deleteQuery, con);



                    var reply = MessageBox.Show("Are you sure", "", MessageBoxButtons.YesNo);

                    if (reply.ToString().ToLower().Equals("yes"))
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Unsbscribed successfully!");
                        HomeForm homeForm = new HomeForm();
                        homeForm.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Please reselect");
                    }
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("error");
            }
        }

        public void cancel_Click(object sender, EventArgs e)
        {
            HomeForm homeForm = new HomeForm();
            homeForm.Show();
            this.Close();
        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {

        }
    }
    
}
